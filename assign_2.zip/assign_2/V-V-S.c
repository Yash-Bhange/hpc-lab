#include<omp.h>
#include<stdio.h>
#include<stdlib.h>

int main()
{
	int n=6;
	
	int array1[n],array2[n],array3[n],i;
	
	for(i=0;i<n;i++)
	{
		array1[i] = i;
		array2[i] = i + 200;
	}
	
	
	
	#pragma omp parallel for shared(array1,array2,array3) num_threads(3)
	for(i=0;i<n;i++)
	{
		array3[i] = array1[i] + array2[i];
		printf("Thread %d working on section %d\n", omp_get_thread_num(), i);
	}
	
	printf("i\ta[i]\t+\tb[i]\t=\tc[i]\n");
    for(i=0; i<n; i++) {
		printf("%d\t%d\t\t%d\t\t%d\n", i, array1[i], array2[i], array3[i]);
    }
	return 0;
}
