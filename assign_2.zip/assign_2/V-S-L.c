#include<omp.h>
#include<stdio.h>
#include<stdlib.h>


int main()
{
	int n=6;

	int array1[n],scalar,array2[n],i;
	
	for(i=0;i<n;i++)
	{
		array1[i] = i;
	}
	//scalar 
        scalar=5;
	
	omp_set_num_threads(3);
	
	#pragma omp parallel for shared(i)
	for(i=0;i<n;i++)
	{
		array2[i] = array1[i] + scalar;
		printf("Thread %d working on section %d\n", omp_get_thread_num(), i);
	}
	
	printf("i\ta[i]\t+\t%d\t=\tc[i]\n",scalar);
    for(i=0; i<n; i++) {
		printf("%d\t%d\t\t%d\t\t%d\n", i, array1[i], scalar, array2[i]);
    }
	return 0;
}
