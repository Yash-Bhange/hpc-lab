#include<omp.h>
#include<stdio.h>
#include<stdlib.h>

int main(int argCount, char* argArray[]){

	#pragma omp parallel
	{

		
		printf("welcome to first practical from thread : %d\n",omp_get_thread_num());
		
		
			
		
		
	}

     printf("program executed by : 2018BTECS00109\n");
	
}

