#include<stdio.h>
int main()
{
  excel(/bin/ls,"ls",0);
   printf("yash");
return 0;
}
